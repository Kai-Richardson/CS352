# Roadmap #

## v0.3.2 ##

Expected mid-November 2013

- Add "cut" operators to trim unneeded parser state

## v0.4.0 ##

Likely December 2013

- Implement some form of automatic cut insertion.

## v1.0.0 ##

Maybe summer 2014

- Implement all pending features, code cleanup, and bugfixes in TODO
